
from .user import *


class Plan(models.Model):
    PLANS = (
        ('SHORT', 'Short-term'),
        ('LONG', 'Long-term'),
    )
    name = models.CharField(choices=PLANS, max_length=6, null=False, unique=True)
    days = models.IntegerField(unique=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Investment Plan"
        verbose_name_plural = "Investment Plan"

    def __str__(self):
        return "{0}".format(self.name)
