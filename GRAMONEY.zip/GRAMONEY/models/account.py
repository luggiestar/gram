import random
import string

from .user import *


def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


class Account(models.Model):
    code = models.CharField(max_length=6, null=False, unique=True)
    invite = models.CharField(max_length=6, null=True, blank=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=False)

    # def save(self, *args, **kwargs):
    #
    #     try:
    #
    #         check_code = Account.objects.get(code=self.code)
    #         check = Account.objects.get(code=self.invite)
    #         if check_code and check:
    #             self.invite = check.code
    #         elif not check_code and check:
    #             self.code = id_generator()
    #             self.invite = check.code
    #     except:
    #         self.code = id_generator()
    #         self.invite = ''
    #
    #     return super(Account, self).save(*args, **kwargs)

    class Meta:
        unique_together = ('code', 'invite')

        verbose_name = "Account"
        verbose_name_plural = "Accounts"

    def __str__(self):
        return "{0}-{1}".format(self.code, self.user)
