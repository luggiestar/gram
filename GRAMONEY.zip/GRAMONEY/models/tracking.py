import decimal
from datetime import datetime, timedelta

from .investment import *
from .account import *


class InvestmentTracking(models.Model):
    investment = models.ForeignKey('Investment', on_delete=models.CASCADE)
    total_referral = models.DecimalField(max_digits=14, decimal_places=2, blank=False, default=0.00, editable=False)
    total_earning = models.DecimalField(max_digits=14, decimal_places=2, blank=False, default=0.00, editable=False)
    total_withdraw = models.DecimalField(max_digits=14, decimal_places=2, blank=False, default=0.00, editable=False)
    balance = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    date = models.DateField(auto_now=True)

    # def save(self, *args, **kwargs):
    #     if self.total_earning >=1:
    #         self.balance = (self.balance+ self.total_earning + self.total_referral) - self.total_withdraw
    #
    #     return super(InvestmentTracking, self).save(*args, **kwargs)

    class Meta:
        verbose_name = "Investment Tracking"
        verbose_name_plural = "Investments Tracking"

    def __str__(self):
        return "{0}-{1}".format(self.investment, self.balance)
