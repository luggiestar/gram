import decimal
from datetime import datetime, timedelta

from django.db.models import Sum

from . import Investment, InvitationEarning
from .investment_plan import *
from .account import *


def id_generator(size=12, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


class Withdraw(models.Model):
    investment = models.ForeignKey(Investment, on_delete=models.CASCADE)
    payment_number = models.CharField(max_length=15, null=True, blank=True, unique=True,editable=False)
    amount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    date = models.DateField(auto_now=True)
    is_confirmed = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if self.is_confirmed:
            self.payment_number = id_generator()

        return super(Withdraw, self).save(*args, **kwargs)

    class Meta:
        verbose_name = "Withdraw  Request"
        verbose_name_plural = "Withdraw Requests"

    def __str__(self):
        return "{0}-{1}".format(self.investment.account, self.amount)
