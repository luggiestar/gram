import decimal
from datetime import datetime, timedelta


from .tracking import *
from .investment_plan import *
from .account import *


class Investment(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE)
    start = models.DateField(auto_now_add=True, editable=False)
    end = models.DateField(null=False, blank=False, editable=False)
    amount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    roi = models.DecimalField(max_digits=14, decimal_places=2, blank=False, editable=False)
    day_earning = models.DecimalField(max_digits=14, decimal_places=2, blank=False, editable=False)
    is_active = models.BooleanField(default=True)
    is_sent = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if self.end == datetime.today():
            self.is_active = False
        elif self.plan:
            self.end = datetime.today() + timedelta(days=self.plan.days)
            if self.plan.name == 'SHORT':
                try:
                    # get_latest_balance = InvestmentTracking.objects.filter(investment__account=self.account).order_by(
                    #     '-id').first()
                    # self.amount = get_latest_balance.balance + self.amount
                    get_roi = self.amount * decimal.Decimal(0.3)
                    self.roi = self.amount + get_roi
                    self.day_earning = get_roi / self.plan.days
                except:

                    get_roi = self.amount * decimal.Decimal(0.3)
                    self.roi = self.amount + get_roi
                    self.day_earning = get_roi / self.plan.days

            else:
                try:
                    # get_latest_balance = InvestmentTracking.objects.filter(investment__account=self.account).order_by(
                    #     '-id').first()
                    # self.amount = get_latest_balance.balance + self.amount
                    get_roi = self.amount * decimal.Decimal(0.6)
                    self.roi = self.amount + get_roi
                    self.day_earning = get_roi / self.plan.days
                except:

                    get_roi = self.amount * decimal.Decimal(0.6)
                    self.roi = self.amount + get_roi
                    self.day_earning = get_roi / self.plan.days

        return super(Investment, self).save(*args, **kwargs)

    class Meta:
        verbose_name = "Investment"
        verbose_name_plural = "Investments"

    def __str__(self):
        return "{0}-{1}".format(self.account, self.amount)
