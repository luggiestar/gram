import decimal
from datetime import datetime, timedelta

from .investment import *
from .investment_plan import *
from .account import *


class DailyEarning(models.Model):
    investment = models.ForeignKey(Investment, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00, editable=False)
    date = models.DateField(auto_now=True)

    def save(self, *args, **kwargs):
        if self.__class__.objects.filter(investment=self.investment).count() == self.investment.plan.days - 1:
            Investment.objects.filter(id=self.investment.id).update(is_active=False)

        elif self.investment.is_active and self.__class__.objects.filter(
                investment=self.investment).count() <= self.investment.plan.days - 1:
            self.amount = self.investment.day_earning
        else:
            return None

        return super(DailyEarning, self).save(*args, **kwargs)

    class Meta:
        verbose_name = "Daily Earning"
        verbose_name_plural = "Daily Earnings"

    def __str__(self):
        return "{0}-{1}".format(self.investment, self.amount)
