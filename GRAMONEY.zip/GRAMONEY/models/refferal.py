import decimal
from datetime import datetime, timedelta

from . import Investment
from .investment_plan import *
from .account import *


class InvitationEarning(models.Model):
    investment = models.OneToOneField(Investment, on_delete=models.CASCADE)
    inviter = models.ForeignKey(Account, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00, editable=False)
    date = models.DateField(auto_now=True)

    def save(self, *args, **kwargs):
        if self.investment.account.invite:
            get_inviter = Account.objects.get(code=self.investment.account.invite)
            get_roi = self.investment.amount * decimal.Decimal(0.03)
            self.amount = get_roi
            self.inviter = get_inviter

        else:
            return None

        return super(InvitationEarning, self).save(*args, **kwargs)

    class Meta:
        verbose_name = "Invitation  Earning"
        verbose_name_plural = "Invitation Earnings"

    def __str__(self):
        return "{0}-{1}".format(self.investment, self.amount)
